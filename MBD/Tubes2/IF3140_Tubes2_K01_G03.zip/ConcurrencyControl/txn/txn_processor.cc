// Author: Alexander Thomson (thomson@cs.yale.edu)
// Modified by: Christina Wallin (christina.wallin@yale.edu)

#include "txn/txn_processor.h"
#include <stdio.h>

#include <set>

#include "txn/lock_manager.h"

// Thread & queue counts for StaticThreadPool initialization.
#define THREAD_COUNT 100
#define QUEUE_COUNT 10

TxnProcessor::TxnProcessor(CCMode mode)
    : mode_(mode), tp_(THREAD_COUNT, QUEUE_COUNT), next_unique_id_(1)
{
  if (mode_ == LOCKING_EXCLUSIVE_ONLY)
    lm_ = new LockManagerA(&ready_txns_);
  else if (mode_ == LOCKING)
    lm_ = new LockManagerB(&ready_txns_);

  // Start 'RunScheduler()' running as a new task in its own thread.
  tp_.RunTask(
      new Method<TxnProcessor, void>(this, &TxnProcessor::RunScheduler));
}

TxnProcessor::~TxnProcessor()
{
  if (mode_ == LOCKING_EXCLUSIVE_ONLY || mode_ == LOCKING)
    delete lm_;
}

void TxnProcessor::NewTxnRequest(Txn *txn)
{
  // Atomically assign the txn a new number and add it to the incoming txn
  // requests queue.
  mutex_.Lock();
  txn->unique_id_ = next_unique_id_;
  next_unique_id_++;
  txn_requests_.Push(txn);
  mutex_.Unlock();
}

Txn *TxnProcessor::GetTxnResult()
{
  Txn *txn;
  while (!txn_results_.Pop(&txn))
  {
    // No result yet. Wait a bit before trying again (to reduce contention on
    // atomic queues).
    sleep(0.000001);
  }
  return txn;
}

void TxnProcessor::RunScheduler()
{
  switch (mode_)
  {
  case SERIAL:
    RunSerialScheduler();
  case LOCKING:
    RunLockingScheduler();
  case LOCKING_EXCLUSIVE_ONLY:
    RunLockingScheduler();
  case OCC:
    RunOCCScheduler();
  case P_OCC:
    RunOCCParallelScheduler();
  }
}

void TxnProcessor::RunSerialScheduler()
{
  Txn *txn;
  while (tp_.Active())
  {
    // Get next txn request.
    if (txn_requests_.Pop(&txn))
    {
      // Execute txn.
      ExecuteTxn(txn);

      // Commit/abort txn according to program logic's commit/abort decision.
      if (txn->Status() == COMPLETED_C)
      {
        ApplyWrites(txn);
        txn->status_ = COMMITTED;
      }
      else if (txn->Status() == COMPLETED_A)
      {
        txn->status_ = ABORTED;
      }
      else
      {
        // Invalid TxnStatus!
        DIE("Completed Txn has invalid TxnStatus: " << txn->Status());
      }

      // Return result to client.
      txn_results_.Push(txn);
    }
  }
}

void TxnProcessor::RunLockingScheduler()
{
  Txn *txn;
  while (tp_.Active())
  {
    // Start processing the next incoming transaction request.
    if (txn_requests_.Pop(&txn))
    {
      int blocked = 0;
      // Request read locks.
      for (set<Key>::iterator it = txn->readset_.begin();
           it != txn->readset_.end(); ++it)
      {
        if (!lm_->ReadLock(txn, *it))
          blocked++;
      }

      // Request write locks.
      for (set<Key>::iterator it = txn->writeset_.begin();
           it != txn->writeset_.end(); ++it)
      {
        if (!lm_->WriteLock(txn, *it))
          blocked++;
      }

      // If all read and write locks were immediately acquired, this txn is
      // ready to be executed.
      if (blocked == 0)
        ready_txns_.push_back(txn);
    }

    // Process and commit all transactions that have finished running.
    while (completed_txns_.Pop(&txn))
    {
      // Release read locks.
      for (set<Key>::iterator it = txn->readset_.begin();
           it != txn->readset_.end(); ++it)
      {
        lm_->Release(txn, *it);
      }
      // Release write locks.
      for (set<Key>::iterator it = txn->writeset_.begin();
           it != txn->writeset_.end(); ++it)
      {
        lm_->Release(txn, *it);
      }

      // Commit/abort txn according to program logic's commit/abort decision.
      if (txn->Status() == COMPLETED_C)
      {
        ApplyWrites(txn);
        txn->status_ = COMMITTED;
      }
      else if (txn->Status() == COMPLETED_A)
      {
        txn->status_ = ABORTED;
      }
      else
      {
        // Invalid TxnStatus!
        DIE("Completed Txn has invalid TxnStatus: " << txn->Status());
      }

      // Return result to client.
      txn_results_.Push(txn);
    }

    // Start executing all transactions that have newly acquired all their
    // locks.
    while (ready_txns_.size())
    {
      // Get next ready txn from the queue.
      txn = ready_txns_.front();
      ready_txns_.pop_front();

      // Start txn running in its own thread.
      tp_.RunTask(new Method<TxnProcessor, void, Txn *>(
          this,
          &TxnProcessor::ExecuteTxn,
          txn));
    }
  }
}

void TxnProcessor::RunOCCScheduler()
{
  // CPSC 438/538:
  //
  // Implement this method! Note that implementing OCC may require
  // modifications to the Storage engine (and therefore to the 'ExecuteTxn'
  // method below).
  //
  // [For now, run serial scheduler in order to make it through the test
  // suite]

  // ALGORITMA MENGACU PSEUDOCODE YANG ADA DI README

  Txn *transaction_pointer; // pointer transaksi

  // Selama thread masih aktif
  while (this->tp_.Active())
  {
    // Cek apakah ada request transaksi yang belum dijalankan
    if (this->txn_requests_.Pop(&transaction_pointer))
    {
      // Jika ada labelkan transaksi ini dengan current timestamp
      transaction_pointer->occ_start_time_ = GetTime();

      // Jalankan Transaksi pada Thread tersendiri
      this->tp_.RunTask(new Method<TxnProcessor, void, Txn *>(
          this,
          &TxnProcessor::ExecuteTxn,
          transaction_pointer));
    }

    // Cek apakah ada transaksi yang sudah selesai
    while (this->completed_txns_.Pop(&transaction_pointer))
    {

      // Fase Validasi Transaksi
      // Jika transaksi selesai karena ABORT
      if (transaction_pointer->Status() == COMPLETED_A)
      {
        // Transaksi tidak valid
        transaction_pointer->status_ = ABORTED;
        this->txn_results_.Push(transaction_pointer);
        continue;
      }

      // Jika transaksi selesai dan mau commit
      // Asumsikan sementara bahwa transaksi valid
      bool valid = true;
      // Cek untuk seluruh data yang dibaca oleh transaksi
      map<Key, Value>::iterator pointer_data_dibaca = transaction_pointer->reads_.begin();
      while (pointer_data_dibaca != transaction_pointer->reads_.end())
      {
        // Cek apakah ada data yang dibaca namun ternyata di update oleh transaki lain yang sudah commit
        if (this->storage_.Timestamp(pointer_data_dibaca->first) > transaction_pointer->occ_start_time_)
        {
          // Jika Ada, maka transaksi invalid dan transaksi harus diabort dan di queue ulang
          valid = false;
          break;
        }
        pointer_data_dibaca++;
      }

      // Jika transaksi valid
      if (valid)
      {
        // Commit transaksi
        ApplyWrites(transaction_pointer);
        transaction_pointer->status_ = COMMITTED;
        this->txn_results_.Push(transaction_pointer);
      }
      else
      {
        // Jika transaksi invalid, maka
        // Hapus seluruh data pembacaan
        transaction_pointer->reads_.clear();
        // Hapus seluruh data penulisan
        transaction_pointer->writes_.clear();
        transaction_pointer->status_ = INCOMPLETE;
        // Queue transaksi ulang
        this->txn_requests_.Push(transaction_pointer);
      }
    }
  }
}

void TxnProcessor::RunOCCParallelScheduler()
{
  // CPSC 438/538:
  //
  // Implement this method! Note that implementing OCC with parallel
  // validation may require modifications to other files, most likely
  // txn_processor.h and possibly others.
  //
  // [For now, run serial scheduler in order to make it through the test
  // suite]

  RunSerialScheduler();
}

void TxnProcessor::ExecuteTxn(Txn *txn)
{
  // Read everything in from readset.
  for (set<Key>::iterator it = txn->readset_.begin();
       it != txn->readset_.end(); ++it)
  {
    // Save each read result iff record exists in storage.
    Value result;
    if (storage_.Read(*it, &result))
      txn->reads_[*it] = result;
  }

  // Also read everything in from writeset.
  for (set<Key>::iterator it = txn->writeset_.begin();
       it != txn->writeset_.end(); ++it)
  {
    // Save each read result iff record exists in storage.
    Value result;
    if (storage_.Read(*it, &result))
      txn->reads_[*it] = result;
  }

  // Execute txn's program logic.
  txn->Run();

  // Hand the txn back to the RunScheduler thread.
  completed_txns_.Push(txn);
}

void TxnProcessor::ApplyWrites(Txn *txn)
{
  // Write buffered writes out to storage.
  for (map<Key, Value>::iterator it = txn->writes_.begin();
       it != txn->writes_.end(); ++it)
  {
    storage_.Write(it->first, it->second);
  }

  // Set status to committed.
  txn->status_ = COMMITTED;
}
