// Author: Alexander Thomson (thomson@cs.yale.edu)
//
// Lock manager implementing deterministic two-phase locking as described in
// 'The Case for Determinism in Database Systems'.

#include "txn/lock_manager.h"

LockManagerA::LockManagerA(deque<Txn *> *ready_txns)
{
  ready_txns_ = ready_txns;
}

bool LockManagerA::WriteLock(Txn *txn, const Key &key)
{
  // CPSC 438/538:
  //
  // Implement this method!

  // Cek apakah ada sudah ada antrian untuk XL(key)
  unordered_map<Key, deque<LockRequest> *>::iterator pointer = lock_table_.find(key);

  // Jika belum ada antrian (artinya belum ada yang pernah pegang XL(key) juga)
  if (pointer == lock_table_.end())
  {
    // Ambil XL(key) tersebut
    LockRequest *new_lock = new LockRequest(EXCLUSIVE, txn);
    // buat antrian baru dan masukkan XL(key) yang dibuat ke antrian baru
    deque<LockRequest> *lock_queue = new deque<LockRequest>();
    lock_queue->push_back(*new_lock);

    // masukkan data antrian lock tersebut ke lock manager
    lock_table_.insert({key, lock_queue});
    // Transaksi bisa berlanjut (ditandai dengan 0)
    txn_waits_.insert({txn, 0});
    return true;
  }

  // Jika sudah pernah ada antrian untuk sebuah XL(key)
  else
  {
    // Buat request XL(key) baru atas nama transaksi saat ini
    LockRequest lock = LockRequest(EXCLUSIVE, txn);

    // Masukkan lock tersebut ke antrian lock
    deque<LockRequest> *lock_queue = pointer->second;
    lock_queue->push_back(lock);

    // Cek apakah sebenarnya antriannya kosong sehingga
    // yang kita masukkan merupakan satu-satunya request untuk XL(key) tersebut
    if (lock_queue->size() == 1)
    {
      // Jika benar requestt XL(key) tadi merupakan satu-satunya request untuk XL(key) tersebut,
      // XL(key) bisa didapat dan transaksi bisa berlanjut tanpa perlu menunggu (ditandai dengan 0)
      txn_waits_.insert({txn, 0});
      return true;
    }

    // Jika ternyata sudah ada XL(key) lain di antrian
    else
    {
      // Transaksi harus menunggu, maka jumlah request lock yang ditunggu transaksi tersebut bertambah 1

      // Cek apakah transaksi sudah pernah melakukan request lock sebelumnya (ditanai dengan adanya key transaksi saat ini di txn_waits_)
      unordered_map<Txn *, int>::iterator current_transaction = txn_waits_.find(txn);

      // Jika belum pernah melakukan request lock sebelumnya
      if (current_transaction == txn_waits_.end())
      {
        // Masukkan request lock dengan jumlah yang ditunggu = 1
        txn_waits_.insert({txn, 1});
      }

      // Jika sudah pernah melakukan request lock sebelumnya
      else
      {
        // Tambahkan jumlah lock yang harus ditunggu dengan 1
        current_transaction->second += 1;
      }
      return false;
    }
  }
}

bool LockManagerA::ReadLock(Txn *txn, const Key &key)
{
  // Since Part 1A implements ONLY exclusive locks, calls to ReadLock can
  // simply use the same logic as 'WriteLock'.
  return WriteLock(txn, key);
}

void LockManagerA::Release(Txn *txn, const Key &key)
{
  // CPSC 438/538:
  //
  // Implement this method!

  // Cek apakah ada antrian untuk XL(key) karena jika tidak ada antrian, maka tidak ada yang bisa di lepas
  unordered_map<Key, deque<LockRequest> *>::iterator lock_table_pointer = lock_table_.find(key);

  // Jika ada antrian
  if (lock_table_pointer != lock_table_.end())
  {
    // cek apakah transaksi *txn bisa melepas XL(key)
    // Iterasi antrian key untuk mencari request XL(key) yang dimiliki oleh transaksi *txn
    deque<LockRequest>::iterator lock_request_pointer = lock_table_pointer->second->begin();
    while (lock_request_pointer != lock_table_pointer->second->end())
    {
      // Jika request XL(key) yang dimiliki oleh transaksi *txn ditemukan
      if (lock_request_pointer->txn_ == txn)
      {
        // Jika request tersebut bukan request XL(key) pertama di antrian
        if (lock_request_pointer != lock_table_pointer->second->begin())
        {
          // *txn masih belum memiliki XL(key) tersebut
          // maka cari apakah transaksi ini ada di antrian menunggu lock
          unordered_map<Txn *, int>::iterator waiting_queue_pointer = txn_waits_.find(txn);

          // jika ketemu bahwa transaksi saat ini sedang menunggu lock
          if (waiting_queue_pointer != txn_waits_.end())
          {
            // hapus transaksi dari antrian menunggu lock
            txn_waits_.erase(txn);
          }

          // hapus request XL(key) yang dilakukan oleh transaksi ini
          lock_table_pointer->second->erase(lock_request_pointer);
        }

        // jika request XL(key) merupakan request pertama (pemegang Key), hapus key
        else
        {
          deque<LockRequest>::iterator next_transaction = lock_table_pointer->second->erase(lock_request_pointer);

          // cek apakah ada transaksi lain yang sedang menuggu XL(key) tersebut
          if (next_transaction != lock_table_pointer->second->end())
          {
            // Jika ada transaksi lain yang menunggu XL(key) tersebut
            // Cari transaksi tersebut di antrian menunggu lock
            unordered_map<Txn *, int>::iterator waiting_lock_pointer = txn_waits_.find(next_transaction->txn_);
            // Jika tidak ketemu
            if (waiting_lock_pointer == txn_waits_.end())
            {
              // hapus request transaksi ini terhadap XL(key)
              next_transaction = lock_table_pointer->second->erase(next_transaction);
            }

            // Jika ketemu, maka kurangi jumlah lock yang di tunggu sebanyak 1
            else
            {
              waiting_lock_pointer->second -= 1;
              // Jika jumlah lock yang di tunggu sudah 0, maka transaksi tersebut bisa berlanjut
              if (waiting_lock_pointer->second == 0)
              {
                // masukkan transaksi tersebut ke antrian transaksi yang siap dieksekusi
                ready_txns_->push_back(next_transaction->txn_);
              }
            }
          }
        }
      }
      lock_request_pointer += 1;
    }
  }
}

LockMode LockManagerA::Status(const Key &key, vector<Txn *> *owners)
{
  // CPSC 438/538:
  //
  // Implement this method!

  // Hapus Owner-owner terdahulu
  owners->clear();

  // Cek apakah ada antrian untuk XL(key)
  unordered_map<Key, deque<LockRequest> *>::iterator pointer = lock_table_.find(key);

  // Jika tidak ada antrian untuk XL(key)
  if (pointer == lock_table_.end())
  {
    // Maka tidak ada owner untuk XL(key)
    return UNLOCKED;
  }

  // Jika PERNAH ada antrian untuk XL(key)
  else
  {
    // Iterasi data antrian XL(key)
    deque<LockRequest>::iterator pointer_antrian = pointer->second->begin();

    // Jika tidak ada data dalam antrian
    if (pointer_antrian == pointer->second->end())
    {
      // Maka tidak ada pemilik XL(key) atau dengan kata lain tidak ada owner
      return UNLOCKED;
    }

    // Jika ada data dalam antrian
    owners->push_back(pointer_antrian->txn_);
    return EXCLUSIVE;
  }
  return UNLOCKED;
}

LockManagerB::LockManagerB(deque<Txn *> *ready_txns)
{
  ready_txns_ = ready_txns;
}

bool LockManagerB::WriteLock(Txn *txn, const Key &key)
{
  // CPSC 438/538:
  //
  // Implement this method!
  return true;
}

bool LockManagerB::ReadLock(Txn *txn, const Key &key)
{
  // CPSC 438/538:
  //
  // Implement this method!
  return true;
}

void LockManagerB::Release(Txn *txn, const Key &key)
{
  // CPSC 438/538:
  //
  // Implement this method!
}

LockMode LockManagerB::Status(const Key &key, vector<Txn *> *owners)
{
  // CPSC 438/538:
  //
  // Implement this method!
  return UNLOCKED;
}
